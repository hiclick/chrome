$(document).ready(function(){

	$(".diaporama1").jDiaporama({
		animationSpeed: "slow",
		delay:2
	});

});